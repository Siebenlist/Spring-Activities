package com.example.enrutamiento;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EnrutamientoApplicationTests {

	@Test
	void contextLoads() {
	}

}
