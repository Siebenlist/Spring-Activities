function getDate(){
	alert("This is the date template");
}

function getTime(){
	alert("This is the time template");
}