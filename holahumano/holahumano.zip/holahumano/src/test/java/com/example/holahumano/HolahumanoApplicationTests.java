package com.example.holahumano;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HolahumanoApplicationTests {

	@Test
	void contextLoads() {
	}

}
